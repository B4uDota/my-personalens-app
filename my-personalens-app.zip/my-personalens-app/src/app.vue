<template>
    <WelcomeScreen /> 
  </template>
  
  <script>
  import WelcomeScreen from './components/WelcomeScreen.vue';
  
  export default {
    components: {
      WelcomeScreen,
    },
  }
  </script>